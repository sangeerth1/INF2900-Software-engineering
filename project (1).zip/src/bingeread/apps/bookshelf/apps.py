from django.apps import AppConfig


class ListConfig(AppConfig):
    name = 'bookshelf'
