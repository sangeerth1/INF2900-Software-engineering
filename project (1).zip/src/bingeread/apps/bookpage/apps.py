from django.apps import AppConfig


class BookpageConfig(AppConfig):
    name = 'bookpage'
