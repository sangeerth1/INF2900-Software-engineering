from django.apps import AppConfig


class ScoresConfig(AppConfig):
    name = 'scores'
